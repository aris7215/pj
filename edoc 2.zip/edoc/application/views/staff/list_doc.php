<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
        รายละเอียด
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo  site_url('staff'); ?>"><i class="fa fa-dashboard"></i> หน้าแรก</a></li>
            <li class="active"> จัดการ </li>
        </ol>
    </section>
    <!-- Top menu -->
    <?php // echo $this->session->flashdata('msginfo'); ?>
    <!-- Main content -->
    <section class="content">
        <!-- Your Page Content Here -->
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">ตารางข้อมูล</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                        <div class="row">
                            <div class="col-sm-6">
                                <a class="btn btn-success" href="<?php echo  site_url('staff/adding'); ?>" role="button"><i class="fa fa-fw fa-plus-circle"></i> เพิ่มข้อมูล</a>
                                <a class="btn btn-default" href="<?php echo  site_url('staff'); ?>" role="button"><i class="fa fa-fw fa-refresh"></i> Refresh Data</a>
                            </div>
                            <div class="col-sm-6">
                                
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <br />
                                <table id="example1" class="table table-bordered table-striped dataTable" role="grid" aria-describedby="example1_info">
                                    <thead>
                                        <tr role="row" class="info">
                                            <th  tabindex="0" rowspan="1" colspan="1" style="width: 5%;">รหัสนศ</th>
                                            <th  tabindex="0" rowspan="1" colspan="1" style="width: 45%;">รายละเอียด</th>
                                            <th  tabindex="0" rowspan="1" colspan="1" style="width: 15%;">ชื่อนศ</th>
                                            <th  tabindex="0" rowspan="1" colspan="1" style="width: 15%;">วัน เวลา ยืม</th>
                                            <th  tabindex="0" rowspan="1" colspan="1" style="width: 5%;">แก้ไข</th>
                                            <th  tabindex="0" rowspan="1" colspan="1" style="width: 5%;">docs</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($query as $row) { ?>
                                        <tr role="row">
                                            
                                            <td align="center"><?php echo $row->doc_num;?></td>
                                            <td>
                                                <?php 
                                                //echo '<font color="blue">';
                                                //echo '<b>';
                                                echo '<font color="blue"><b>สิ่งของ ';
                                                echo $row->dname;
                                                echo '</b></font>';
                                                //echo '</font>';
                                                echo nbs(10);
                                               // echo '<font color="red"><b>';
                                                //$ds = $row->doc_status;
                                                //if($ds==1){
                                                    //echo 'อ่านได้ทุกระดับ';
                                                //}else{
                                                   // echo 'เฉพาะผู้บริหาร';
                                               // }
                                                //echo '</b></font>';
                                                echo br();
                                                echo ' วันที่จะคืน ';
                                                echo date('d/m/Y',strtotime($row->doc_date));

                                            $df = $row->doc_file;
                                            if($df !=''){ ?>
                                           
                                        <?php } ?>

                                                    
                                                </td>
                                            <td><?php echo $row->doc_name;?></td>
                                            <td><?php echo $row->doc_save;?></td>
                                            
                                            <td>
                                                    <a href="<?php echo site_url('staff/edit/'.$row->doc_id); ?>" class="btn btn-warning btn-xs">
                                                        แก้ไข
                                                    </a>
                                                </td>
                                                <td>
                                        <?php 
                                            $df = $row->doc_file;
                                            if($df !=''){ ?>
                                           
                                            <a href="<?php echo base_url('docs/'.$row->doc_file);?>" target="_blank" class="btn btn-info btn-xs"> เปิดดูบัตรนศ </a>
                                        <?php }else{
                                            echo '-';

                                        } ?>
                                                </td>
                                            </tr>
                                            <?php  } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        </div><!-- /.box-body -->
                    </div>
                    </section><!-- /.content -->
                    </div><!-- /.content-wrapper -->