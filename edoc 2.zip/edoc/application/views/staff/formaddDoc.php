<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
         ฟอร์มเพิ่ม
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo  site_url('staff'); ?>"><i class="fa fa-dashboard"></i> หน้าแรก</a></li>
            <li><a href="<?php echo  site_url('staff'); ?>"> จัดการ </a></li>
            <li class="active">เพิ่มข้อมูลใหม่</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <!-- Your Page Content Here -->
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <!-- <h3 class="box-title"> +ข่าวใหม่ </h3> -->
                            </div><!-- /.box-header -->
                            <!-- form start -->
                            <form role="form" action="<?php echo  site_url('staff/adddoc'); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                                <div class="box-body">
                                   <!-- <div class="form-group">
                                        <div class="col-sm-2 control-label">
                                            สิทธิ
                                        </div>
                                        <div class="col-sm-4">
                                            <select name="doc_status" class="form-control" required>
                                                <option value="1">-อ่านได้ทุกตำแหน่ง-</option>
                                                <option value="2">-เฉพาะผู้บริหาร-</option>
                                            </select>
                                        </div>
                                    </div>-->
                                    <div class="form-group">
                                        <div class="col-sm-2 control-label">
                                            สิ่งของ
                                        </div>
                                        <div class="col-sm-4">
                                            <select name="ref_did" class="form-control" >
                                                <option value="">-เลือกข้อมูล-</option>

                                                <?php foreach ($rsdt as $rs) { ?>
                                                <option value="<?php echo $rs->did;?>">-<?php echo $rs->dname;?>-</option>
                                            <?php }?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-2 control-label">
                                            รหัสนศ
                                        </div>
                                        <div class="col-sm-4">
                                            <input type="text" name="doc_num" class="form-control" >
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <div class="col-sm-2 control-label">
                                            ชื่อ
                                        </div>
                                        <div class="col-sm-8">
                                            <input type="text" name="doc_name" class="form-control" >
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-2 control-label">
                                            ลงวันที่จะคืน
                                        </div>
                                        <div class="col-sm-4">
                                            <input type="date" name="doc_date" class="form-control"  >
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-2 control-label">
                                            มาจากห้อง
                                        </div>
                                        <div class="col-sm-8">
                                            <input type="text" name="doc_from" class="form-control" >
                                        </div>
                                    </div>
                                     <!--<div class="form-group">
                                        <div class="col-sm-2 control-label">
                                            ส่งถึง
                                        </div>
                                        <div class="col-sm-4">
                                            <input type="text" name="doc_to" class="form-control" >
                                        </div>
                                    </div>-->
                            
                                    <div class="form-group">
                                        <div class="col-sm-2 control-label">
                                            ไฟล์บัตรนศ pdf
                                        </div>
                                        <div class="col-sm-3">
                                            
                                            <input type="file" name="doc_file" class="form-control"  accept="application/pdf" >
                                        </div>
                                    </div>
                
                                    <div class="form-group">
                                        <div class="col-sm-2 control-label">
                                            
                                        </div>
                                        <div class="col-sm-3">
                                            <button class="btn btn-primary" type="submit">
                                            <i class="fa fa-fw fa-save"></i> บันทึกข้อมูล</button>
                                            <a class="btn btn-danger" href="<?php echo  site_url('staff'); ?>" role="button"><i class="fa fa-fw fa-close"></i> ยกเลิก</a>
                                            
                                            
                                        </div>
                                    </div>
                                    
                                    </div><!-- /.box-body -->
                                </form>
                            </div>
                        </div> </div> </div>
                        </section><!-- /.content -->
                        </div><!-- /.content-wrapper -->