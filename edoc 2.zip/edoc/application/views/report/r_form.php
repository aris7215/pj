<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
        ฟอร์มเรียกดู-ตาม ว/ด/ป
        </h1>
    </section>
    <!-- Top menu -->
    <?php // echo $this->session->flashdata('msginfo'); ?>
    <!-- Main content -->
    <section class="content">
        <!-- Your Page Content Here -->
        <div class="box">
            <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body">
                    <div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap">
                        <div class="row">
                        </div>
                        <div class="row">
                            <div class="col-sm-10">
                                 <form action="<?php echo site_url('report/getform');?>" method="post" class="form-horizontal">
                                      <div class="form-group">
                                        <div class="col-sm-1">
                                            start 
                                        </div>
                                        <div class="col-sm-3">
                                            <input type="date" name="ds" class="form-control" required>
                                        </div>
                                        <div class="col-sm-1">
                                            end 
                                        </div>
                                        <div class="col-sm-3">
                                            <input type="date" name="de" class="form-control" required>
                                        </div>
                                        <div class="col-sm-1">
                                           <button type="submit" class="btn btn-info">Get Report</button>
                                        </div>
                                      </div>
                                 </form>
                               
                            </div>
                        </div>
                    </div>
                    </div><!-- /.box-body -->
                </div>
                </section><!-- /.content -->
                </div><!-- /.content-wrapper -->