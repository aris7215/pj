<?php
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>
		 BACKEND
		</title>
		<!-- tell the browser to be responsive to screen width -->
		<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
		<!-- bootstrap 3.3.4-->
		<?php echo link_tag('bootstrap/css/bootstrap.min.css'); ?>
		<!-- font awesome icons-->
		<?php echo link_tag('bootstrap/css/font-awesome.min.css'); ?>
		<!-- ionicons-->
		<?php echo link_tag('bootstrap/css/ionicons.min.css'); ?>
		<!--Theme style-->
		<?php echo link_tag('dist/css/AdminLTE.min.css'); ?>
		<!--Theme skin -->
		<?php echo link_tag('dist/css/skins/skin-blue.min.css'); ?>
		<!--Theme skin -->
		<?php  echo link_tag('plugins/datatables/dataTables.bootstrap.css'); ?>
		<?php  //echo link_tag('plugins/datatables/dataTables.js'); ?>
		<!--My Custom-->
		<?php echo link_tag('dist/css/mycustom.css'); ?>
		<!-- REQUIRED JS SCRIPTS -->
		<!-- jQuery 2.1.4 -->
		<script src="<?php echo base_url(); ?>plugins/jQuery/jQuery-2.1.4.min.js" type="text/javascript">
		</script>
		<script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js" type="text/javascript">
		</script>
		<script src="<?php echo base_url(); ?>plugins/datatables/dataTables.bootstrap.min.js" type="text/javascript">
		</script>
		<!-- Bootstrap 3.3.2 JS -->
		<script src="<?php echo base_url(); ?>bootstrap/js/bootstrap.min.js" type="text/javascript">
		</script>
		<!-- AdminLTE App -->
		<script src="<?php echo base_url(); ?>dist/js/app.min.js" type="text/javascript">
		</script>
		<!-- ckeditor-->
		<script src="//cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script>
	</head>
	<body class="skin-blue sidebar-mini">
		<div class="wrapper">
			<!-- Main Header -->
			<header class="main-header">
				<!-- Logo -->
				<a href="<?php site_url(); ?>" class="logo">
					<!-- mini logo for sidebar mini 50x50 pixels -->
					<span class="logo-mini">
						<b>
						
						</b>
					</span>
					<!-- logo for regular state and mobile devices -->
					<span class="logo-lg">
						<b>
						 SYSTEM
						</b>
					</span>
				</a>
				<!-- Header Navbar -->
				<nav class="navbar navbar-static-top" role="navigation">
					<!-- Sidebar toggle button-->
					<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
						<span class="sr-only">
							Toggle navigation
						</span>
					</a>
					<!-- Navbar Right Menu -->
					<div class="navbar-custom-menu">
						<ul class="nav navbar-nav">
							<!-- User Account Menu -->
							<li class="dropdown user user-menu">
								<!-- Menu Toggle Button -->
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">
									<!-- The user image in the navbar-->
									<img src="<?php // echo base_url('pimg/'.$pimg); ?>" class="user-image" alt="User Image" />
									<!-- hidden-xs hides the username on small devices so only the image appears. -->
									<span class="hidden-xs">
										<?php // echo $this->session->userdata('display_name')?>
									</span>
								</a>
								<ul class="dropdown-menu">
									<!-- The user image in the menu -->
									<li class="user-header">
										<img src="<?php // echo base_url('pimg/'.$pimg); ?>" class="img-circle" alt="User Image" />
										
										<p>
											<?php // echo $this->session->userdata('username'); ?>
											<small>
											menu
											</small>
										</p>
									</li>
									
									<li class="user-footer">
										<div class="pull-left">
											<a href="<?php // echo  site_url('mprofile'); ?>" class="btn btn-default btn-flat">
												Profile
											</a>
										</div>
										<div class="pull-right">
											<a href="<?php // echo  site_url('user/logout'); ?>" class="btn btn-default btn-flat">
												Sign out
											</a>
										</div>
									</li>
								</ul>
							</li>
							<!-- Control Sidebar Toggle Button -->
							
						</ul>
					</div>
				</nav>
			</header>
			<!-- Left side column. contains the logo and sidebar -->
			<aside class="main-sidebar">
				<!-- sidebar: style can be found in sidebar.less -->
				<section class="sidebar">
					<!-- Sidebar user panel (optional) -->
					<div class="user-panel">
						<div class="pull-left image">
							<img src="<?php // echo base_url('pimg/'.$pimg); ?>" class="img-circle" alt="User Image" />
						</div>
						<div class="pull-left info">
							<p>
								
							</p>
							<!-- Status -->
							<a href="#">
								<i class="fa fa-circle text-success">
								</i>Online
							</a>
						</div>
					</div>
					<?php
					$menus = "active";
					?>
					<!-- sidebar menu: : style can be found in sidebar.less -->
					
					<!-- Admin -->
					
					<ul class="sidebar-menu">
						<li><a href="<?php echo site_url('');?>">
						<i class="fa fa-home"></i> หน้าหลัก</a></li>
						<li class="<?php echo $menus;?>">
							<a href="ads_type">
								<i class="fa fa-files-o"></i>
								<span>คู่มือ</span>
							</a>
							<ul class="treeview-menu">
								<li>
									<a href="<?php echo site_url('');?>">
									<i class="fa fa-circle-o"></i> ผู้ดูแลระบบ </a>
								</li>
								<li>
									<a href="<?php echo site_url('');?>">
									<i class="fa fa-circle-o"></i> ผู้บริหาร </a>
								</li>
								<li>
									<a href="<?php echo site_url('');?>">
									<i class="fa fa-circle-o"></i> สารบรรณ </a>
								</li>
								<li>
									<a href="<?php echo site_url('');?>">
									<i class="fa fa-circle-o"></i> พนักงาน </a>
								</li>
							</ul>
						</li>
						</ul><!-- /.sidebar-menu -->
					</section>
					<!-- /.sidebar -->
				</aside>