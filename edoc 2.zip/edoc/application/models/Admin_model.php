<?php
class Admin_model extends CI_Model 
{

	public $a_name; 
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		# code...
	}
}
