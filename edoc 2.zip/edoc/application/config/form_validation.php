<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['error_prefix'] = '<label class="error">';
$config['error_suffix'] = '</label>';
?>