<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('m_level') !=1){
				redirect('user','refresh');
		}
		$this->load->model('doc_model');
	}

	public function index()
	{
		//print_r($_SESSION);
		$data['query']=$this->doc_model->list_doc_emp();
		$this->load->view('template/backheader');
		$this->load->view('emp/list_doc',$data);
		$this->load->view('template/backfooter');
	}


}