<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Member extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('member_model');
		$this->load->model('position_model');
		if($this->session->userdata('m_level') !=3){
				redirect('user','refresh');
		}
		
	}

	public function index()
	{
		//print_r($_SESSION);
		$data['query']=$this->member_model->list_member();

		// echo '<pre>';
		// print_r($data);
		// echo '</pre>';
		// exit();

		$this->load->view('template/backheader');
		$this->load->view('admin/member',$data);
		$this->load->view('template/backfooter');
	}
	public function adding()
	{

		$data['rspo']=$this->position_model->list_position();

		// echo '<pre>';
		// print_r($data);
		// echo '</pre>';

		// exit;

		$this->load->view('template/backheader');
		$this->load->view('admin/member_form_add',$data);
		$this->load->view('template/backfooter');
	}

	public function adddata()
	{
		// echo '<pre>';
		// print_r($_POST);
		// echo '</pre>';

		// exit;

		 $this->member_model->addmember();
		 redirect('member','refresh');
	}



public function adddata2()
	{
		// echo '<pre>';
		// print_r($_POST);
		// echo '</pre>';

		// exit;

		 $this->member_model->addmember2();
		 redirect('member','refresh');
	}


	public function edit($m_id)
	{
		$data['rsedit']=$this->member_model->read($m_id);
		$data['rspo']=$this->position_model->list_position();

		// print_r($data);

		// exit;

		$this->load->view('template/backheader');
		$this->load->view('admin/member_form_edit',$data);
		$this->load->view('template/backfooter');
	}


	public function pwd($m_id)
	{
		$data['rsedit']=$this->member_model->read($m_id);
		$this->load->view('template/backheader');
		$this->load->view('admin/member_form_pwd',$data);
		$this->load->view('template/backfooter');
	}



	public function editdata()
	{

		// echo '<pre>';
		// print_r($_POST);
		// echo '</pre>';

		// exit;

		$this->member_model->editmember();
		redirect('member','refresh');

	
	}


	public function editpwd()
	{

		// echo '<pre>';
		// print_r($_POST);
		// echo '</pre>';
		// exit;

		$this->member_model->editmemberpwd();
		redirect('member','refresh');

	
	}


	


	public function del($m_id)
	{
		//print_r($_POST);
		$this->member_model->deldata($m_id);
		redirect('member','refresh');


		
	}





}