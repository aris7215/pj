<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Position extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('position_model');
		
	}

	public function index()
	{
		$data['query']=$this->position_model->list_position();

		// echo '<pre>';
		// print_r($data);
		// echo '</pre>';
		// exit();

		$this->load->view('template/backheader');
		$this->load->view('admin/position',$data);
		$this->load->view('template/backfooter');
	}
	public function adding()
	{
		$this->load->view('template/backheader');
		$this->load->view('admin/position_form_add');
		$this->load->view('template/backfooter');
	}

	public function adddata()
	{
		// echo '<pre>';
		// print_r($_POST);
		// echo '</pre>';

		// exit;

		 $this->position_model->addposition();
		 redirect('position','refresh');
	}


	public function edit($pid)
	{
		$data['rsedit']=$this->position_model->read($pid);

		// print_r($data);

		// exit;

		$this->load->view('template/backheader');
		$this->load->view('admin/position_form_edit',$data);
		$this->load->view('template/backfooter');
	}

	public function editdata()
	{

		// echo '<pre>';
		// print_r($_POST);
		// echo '</pre>';

		// exit;

		$this->position_model->editposition();
		redirect('position','refresh');

	
	}


	public function del($pid)
	{
		//print_r($_POST);
		$this->position_model->deldata($pid);
		redirect('position','refresh');


		
	}





}