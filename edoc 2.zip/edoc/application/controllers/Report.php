<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Report extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('m_level') ==4){
				redirect('user','refresh');
		}
		$this->load->model('report_model');
	}

	public function index()
	{
		$data['query']=$this->report_model->count_doc();

		// echo '<pre>';
		// print_r($data);
		// echo '</pre>';
		// exit();
		//print_r($_SESSION);
		$this->load->view('template/backheader_report');
		$this->load->view('report/mainpage',$data);
		$this->load->view('template/backfooter');
	}

	public function doc_status()
	{

		$data['query']=$this->report_model->count_doc_status();

		// echo '<pre>';
		// print_r($data);
		// echo '</pre>';
		// exit();

		$this->load->view('template/backheader_report');
		$this->load->view('report/r_docstatus',$data);
		$this->load->view('template/backfooter');
		 
	}



	public function bytype()
	{
		$data['query']=$this->report_model->count_doc_type();
		// echo '<pre>';
		// print_r($data);
		// echo '</pre>';
		// exit();

		$this->load->view('template/backheader_report');
		$this->load->view('report/r_doctype',$data);
		$this->load->view('template/backfooter');
	}

	public function bytype_excel()
	{
		$data['query']=$this->report_model->count_doc_type();
		$this->load->view('report/r_doctype_ex_excel',$data);
	}

public function bydate()
{
		$data['query']=$this->report_model->count_doc_date();
		// echo '<pre>';
		// print_r($data);
		// echo '</pre>';
		// exit();

		$this->load->view('template/backheader_report');
		$this->load->view('report/r_docdate',$data);
		$this->load->view('template/backfooter');
}

public function bym()
{
	$data['query']=$this->report_model->count_doc_m();
		// echo '<pre>';
		// print_r($data);
		// echo '</pre>';
		// exit();

		$this->load->view('template/backheader_report');
		$this->load->view('report/r_docm',$data);
		$this->load->view('template/backfooter');
}

public function byy()
{
		$data['query']=$this->report_model->count_doc_y();
		// echo '<pre>';
		// print_r($data);
		// echo '</pre>';
		// exit();

		$this->load->view('template/backheader_report');
		$this->load->view('report/r_docy',$data);
		$this->load->view('template/backfooter');
}

 

 public function form()
	{
		$this->load->view('template/backheader_report');
		$this->load->view('report/r_form');
		$this->load->view('template/backfooter');
	}

public function getform()
{

	$data['query']=$this->report_model->count_doc_form();
	// echo '<pre>';
	// print_r($data);
	// echo '</pre>';
	// exit();

		$this->load->view('template/backheader_report');
		$this->load->view('report/list_doc',$data);
		$this->load->view('template/backfooter');
}

public function mychart_m()
{
	$data['query']=$this->report_model->count_doc_m();
	$this->load->view('template/backheader_report');
	$this->load->view('report/mychart',$data);
	$this->load->view('template/backfooter');
	 
}


public function mychart_d()
{
	$data['query']=$this->report_model->count_doc_date();
	$this->load->view('template/backheader_report');
	$this->load->view('report/mychart_d',$data);
	$this->load->view('template/backfooter');
	 
}


public function mychart_y()
{
	$data['query']=$this->report_model->count_doc_y();
	$this->load->view('template/backheader_report');
	$this->load->view('report/mychart_y',$data);
	$this->load->view('template/backfooter');
}


public function mychart_l()
{
	$data['query']=$this->report_model->count_doc_status();
	$this->load->view('template/backheader_report');
	$this->load->view('report/mychart_l',$data);
	$this->load->view('template/backfooter');
}


public function mychart_t()
{
	$data['query']=$this->report_model->count_doc_type();
	$this->load->view('template/backheader_report');
	$this->load->view('report/mychart_t',$data);
	$this->load->view('template/backfooter');
}


public function mychart_t2()
{
	$data['query']=$this->report_model->count_doc_type();
	$this->load->view('template/backheader_report');
	$this->load->view('report/mychart_t2',$data);
	$this->load->view('template/backfooter');
}










}