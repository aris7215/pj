-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 26, 2022 at 06:59 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_db_edoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_doc`
--

CREATE TABLE `tbl_doc` (
  `doc_id` int(11) NOT NULL,
  `ref_did` int(11) NOT NULL COMMENT 'รหัสสิ่งของ',
  `doc_num` varchar(30) DEFAULT NULL COMMENT 'รหัสนศ',
  `doc_name` varchar(300) DEFAULT NULL COMMENT 'ชื่อนศ',
  `doc_from` varchar(200) DEFAULT NULL COMMENT 'เลขที่ห้อง',
  `doc_date` date DEFAULT NULL COMMENT 'วันที่จะคืน',
  `doc_to` varchar(200) DEFAULT NULL,
  `doc_file` varchar(100) DEFAULT NULL,
  `ref_m_id` int(11) NOT NULL COMMENT 'รหัสสารบรรณ',
  `doc_save` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'วันเวลาที่ยืม'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_doc`
--

INSERT INTO `tbl_doc` (`doc_id`, `ref_did`, `doc_num`, `doc_name`, `doc_from`, `doc_date`, `doc_to`, `doc_file`, `ref_m_id`, `doc_save`) VALUES
(1, 1, 'ffff', 'ffff', 'ffff', '2022-07-26', 'ffff', '2fb1291b4b2bececc9b6fb5de4ed08bd.pdf', 0, '2022-07-26 03:29:22'),
(2, 1, 'kk', '', '', '0000-00-00', '', '0899f3c43e5561627d362e4c43da02c5.pdf', 0, '2022-07-26 03:32:42'),
(3, 1, 'llll', '', '', '0000-00-00', '', '775c2c3c491bbc908056c3962da22ced.pdf', 0, '2022-07-26 03:34:37'),
(4, 3, '1111111111', '111111111', '123', '2022-07-26', NULL, '1d3fe33d58d4940528fafc7b0ba17641.pdf', 0, '2022-07-26 04:10:30'),
(5, 3, '123456789', 'miss aris', '123', '2022-07-26', NULL, '647bc4fcd3bd54004d444471419da2cf.pdf', 0, '2022-07-26 04:14:57');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_doc_type`
--

CREATE TABLE `tbl_doc_type` (
  `did` int(11) NOT NULL,
  `dname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_doc_type`
--

INSERT INTO `tbl_doc_type` (`did`, `dname`) VALUES
(1, 'ไม้กวาด'),
(2, 'ไม้ถูพื้น'),
(3, 'เก้าอี้'),
(4, 'พัดลม'),
(6, 'คอม');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member`
--

CREATE TABLE `tbl_member` (
  `m_id` int(11) NOT NULL,
  `ref_pid` int(11) DEFAULT NULL COMMENT 'รหัสตำแหน่ง',
  `m_username` varchar(50) COLLATE utf8_german2_ci NOT NULL,
  `m_password` varchar(50) COLLATE utf8_german2_ci NOT NULL,
  `m_fname` varchar(100) COLLATE utf8_german2_ci NOT NULL,
  `m_name` varchar(100) COLLATE utf8_german2_ci NOT NULL,
  `m_lname` varchar(100) COLLATE utf8_german2_ci NOT NULL,
  `m_datesave` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_german2_ci;

--
-- Dumping data for table `tbl_member`
--

INSERT INTO `tbl_member` (`m_id`, `ref_pid`, `m_username`, `m_password`, `m_fname`, `m_name`, `m_lname`, `m_datesave`) VALUES
(1, 1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'mr.', 'admin', 'root', '2019-03-24 10:43:38'),
(2, 2, 'boss', '05b1f356646c24bf1765f6f1b65aea3bde7247e1', 'mr.', 'bossA', 'B', '2019-03-24 10:43:38'),
(3, 3, 's', 'a0f1490a20d0211c997b44bc357e1972deab8ae3', 'mr.', 'staffA', 'BB', '2019-03-24 10:43:38'),
(4, 4, 'e', '58e6b3a414a1e090dfc6029add0f3555ccba127f', 'mr.', 'emp12a', 'root12a', '2019-03-24 10:43:38'),
(5, 4, 'mm', 'b8d09b4d8580aacbd9efc4540a9b88d2feb9d7e5', 'นาย', 'mmmm', 'bbbbb', '2019-03-26 09:05:44'),
(6, NULL, 'ww', '1c4f0c6eb8bf8bbf11cc2ae1cdcc5c5d1f3a3c16', 'นาย', 'ww', 'ww', '2022-07-26 04:26:33'),
(7, 3, 'www', 'c50267b906a652f2142cfab006e215c9f6fdc8a0', 'นางสาว', 'wwwww', 'wwwww', '2022-07-26 04:27:48');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_position`
--

CREATE TABLE `tbl_position` (
  `pid` int(11) NOT NULL,
  `pname` varchar(100) NOT NULL COMMENT 'ชื่อตำแหน่งงาน'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ตำแหน่งงาน';

--
-- Dumping data for table `tbl_position`
--

INSERT INTO `tbl_position` (`pid`, `pname`) VALUES
(1, 'Admin'),
(3, 'Staff');

-- --------------------------------------------------------

--
-- Table structure for table `tel_st`
--

CREATE TABLE `tel_st` (
  `id_st` int(11) NOT NULL,
  `st_name` varchar(200) DEFAULT NULL,
  `st_room` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_doc`
--
ALTER TABLE `tbl_doc`
  ADD PRIMARY KEY (`doc_id`);

--
-- Indexes for table `tbl_doc_type`
--
ALTER TABLE `tbl_doc_type`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `tbl_member`
--
ALTER TABLE `tbl_member`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `tbl_position`
--
ALTER TABLE `tbl_position`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `tel_st`
--
ALTER TABLE `tel_st`
  ADD PRIMARY KEY (`id_st`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_doc`
--
ALTER TABLE `tbl_doc`
  MODIFY `doc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_doc_type`
--
ALTER TABLE `tbl_doc_type`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_member`
--
ALTER TABLE `tbl_member`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_position`
--
ALTER TABLE `tbl_position`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tel_st`
--
ALTER TABLE `tel_st`
  MODIFY `id_st` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
